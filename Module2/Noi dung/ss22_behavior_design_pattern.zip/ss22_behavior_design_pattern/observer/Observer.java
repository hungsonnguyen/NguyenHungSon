package ss22_behavior_design_pattern.observer;

public interface Observer {
    void care(); //quan tam
}
