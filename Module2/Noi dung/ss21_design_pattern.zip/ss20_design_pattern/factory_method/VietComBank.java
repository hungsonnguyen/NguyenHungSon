package ss20_design_pattern.factory_method;

public class VietComBank implements Bank {

    @Override
    public String getNameBank() {
        return "VietComBank";
    }
}
