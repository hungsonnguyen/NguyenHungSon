package ss20_design_pattern.factory_method;

public interface Bank{
    String getNameBank();
}
