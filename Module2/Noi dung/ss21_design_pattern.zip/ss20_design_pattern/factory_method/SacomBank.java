package ss20_design_pattern.factory_method;

public class SacomBank  implements Bank{
    @Override
    public String getNameBank() {
        return "Sacombank";
    }
}
