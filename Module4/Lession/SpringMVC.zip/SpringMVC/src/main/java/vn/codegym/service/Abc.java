package vn.codegym.service;

import org.springframework.stereotype.Service;
import vn.codegym.model.Student;

import java.util.List;


public class Abc implements IStudentService{
    @Override
    public List<Student> findAll() {
        return null;
    }
}
