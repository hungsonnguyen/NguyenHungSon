package ss20_design_pattern.factory_method;

public enum  TypeBank {
    TPBANK,SACOMBANK,VIETCOMBANK;
}
