package ss18_solid.dependency_inversion_principle.wrong_design;

class Frontend {
    void codeJS(){
        System.out.println("Sử dụng code JS xây dựng FrontEnd");
    }
}
