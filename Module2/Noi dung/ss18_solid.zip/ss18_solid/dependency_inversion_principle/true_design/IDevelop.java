package ss18_solid.dependency_inversion_principle.true_design;

/**
 * Tạo interface IDevelop để module Project phụ thuộc vào nó
 */
public interface IDevelop {
    void develop();
}
