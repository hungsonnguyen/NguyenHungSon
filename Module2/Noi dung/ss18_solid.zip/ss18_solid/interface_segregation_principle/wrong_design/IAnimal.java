package ss18_solid.interface_segregation_principle.wrong_design;

public interface IAnimal {
    void run();
    void swim();
    void fly();
}
