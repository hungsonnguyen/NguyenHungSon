package ss18_solid.interface_segregation_principle.true_design;

public interface IBird {
    void fly();
}
