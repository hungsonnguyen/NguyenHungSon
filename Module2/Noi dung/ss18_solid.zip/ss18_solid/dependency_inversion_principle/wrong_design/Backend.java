package ss18_solid.dependency_inversion_principle.wrong_design;

class Backend {
    void codeJava(){
        System.out.println("Sử dụng code Java xây dựng Backend");
    }
}
