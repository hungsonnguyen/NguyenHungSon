package ss18_solid.liskovs_substitution_principle.wong_design;

public class Animal {
    public void makeNoise(){
        System.out.println("making some noise");
    }
}
