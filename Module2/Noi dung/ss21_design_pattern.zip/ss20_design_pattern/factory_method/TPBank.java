package ss20_design_pattern.factory_method;

public class TPBank implements Bank{
    @Override
    public String getNameBank() {
        return "TPBank";
    }
}
