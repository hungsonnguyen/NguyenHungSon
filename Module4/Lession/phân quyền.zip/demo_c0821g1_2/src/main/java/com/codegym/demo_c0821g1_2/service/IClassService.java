package com.codegym.demo_c0821g1_2.service;

import com.codegym.demo_c0821g1_2.model.ClassRoom;

import java.util.List;

public interface IClassService {
    List<ClassRoom> findAll();
}
