package ss16_binary_file;

import java.io.Serializable;

public class Person implements Serializable {
}
